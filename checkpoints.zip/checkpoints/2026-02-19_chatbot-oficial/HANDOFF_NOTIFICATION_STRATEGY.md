# Estratégia de Notificação para Transbordo Humano - Análise Crítica

**Data:** 2026-02-20
**Status:** 🔴 DECISÃO CRÍTICA - ALTO IMPACTO
**Contexto:** Integração com CRM Automation (handoff para humano)

---

## RESUMO EXECUTIVO - 30 SEGUNDOS

**Problema:** Quando bot detecta necessidade de humano, como notificar o operador?

**Opção A (ARRISCADA):** WhatsApp pessoal do operador
**Opção B (SEGURA):** Notificações in-app + dashboard



## 3. OPÇÃO B - NOTIFICAÇÕES IN-APP (RECOMENDADO)

### Como Funcionaria

**Arquitetura Proposta:**

```
Cliente → Bot detecta handoff
           ↓
    UPDATE crm_cards SET needs_attention = true
           ↓
    ┌─────────────────────────────────────────┐
    │  Sistema de Notificações In-App         │
    ├─────────────────────────────────────────┤
    │  1. Push Notification (Web Push API)    │
    │  2. Badge vermelho no dashboard         │
    │  3. Som de alerta                       │
    │  4. Toast notification                  │
    │  5. Email backup (se não viu em 2 min)  │
    └─────────────────────────────────────────┘
           ↓
    Operador clica → Abre chat direto
           ↓
    Responde no dashboard
           ↓
    Mensagem enviada via Cloud API oficial
```

### Componentes Técnicos

#### 3.1 Web Push Notifications (PWA)

**Tecnologia:** Service Worker + Push API (nativa do navegador)

```typescript
// src/lib/push-notifications.ts

export const requestNotificationPermission = async () => {
  if ('Notification' in window && 'serviceWorker' in navigator) {
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }
  return false;
};

export const sendPushNotification = async (
  userId: string,
  notification: {
    title: string;
    body: string;
    icon: string;
    badge: string;
    data: {
      cardId: string;
      clientId: string;
      phone: string;
      urgency: 'high' | 'medium' | 'low';
    };
  }
) => {
  // Firebase Cloud Messaging ou Web Push API nativa
  const registration = await navigator.serviceWorker.ready;

  await registration.showNotification(notification.title, {
    body: notification.body,
    icon: notification.icon,
    badge: notification.badge,
    tag: notification.data.cardId, // Evita duplicatas
    requireInteraction: notification.data.urgency === 'high',
    vibrate: [200, 100, 200],
    data: notification.data,
    actions: [
      { action: 'open', title: 'Atender Agora' },
      { action: 'snooze', title: 'Lembrar em 5 min' }
    ]
  });
};
```

**Exemplo de Notificação:**

```
┌────────────────────────────────────────┐
│  🔴 ChatBot - Atendimento Urgente      │
├────────────────────────────────────────┤
│  João Silva precisa de atendimento    │
│  humano agora!                         │
│                                        │
│  Motivo: Solicitou falar com vendedor │
│  Origem: Instagram Ads (Quente 🔥)    │
│  Aguardando há: 23 segundos            │
│                                        │
│  [Atender Agora] [Snooze 5min]        │
└────────────────────────────────────────┘
```

**Vantagens:**
- ✅ Funciona mesmo com dashboard fechado (se PWA instalado)
- ✅ Funciona em mobile (Android/iOS)
- ✅ Som + vibração customizável
- ✅ Ações diretas (abrir chat sem navegar)
- ✅ Custo ZERO (browser API nativa)

**Limitações:**
- ⚠️ Requer permissão do usuário (onboarding)
- ⚠️ iOS tem restrições em PWA (melhor via app nativo)
- ⚠️ Precisa de service worker registrado

#### 3.2 Dashboard com Priorização Visual

**UI Proposta:**

```
┌─────────────────────────────────────────────────────────────┐
│  CRM Dashboard                    🔔 3 Atendimentos Urgentes │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ⚠️ AGUARDANDO ATENDIMENTO HUMANO                           │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ 🔴 João Silva                        [Atender Agora]   │ │
│  │ 📱 Instagram Ads • 🔥 Quente (92%)                     │ │
│  │ ⏱️ Aguardando há: 1m 23s                               │ │
│  │ 💬 "Quero falar com um vendedor sobre o plano premium"│ │
│  │ 📊 3 tentativas anteriores de venda • R$ 2.500 valor  │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌────────────────────────────────────────────────────────┐ │
│  │ 🟡 Maria Santos                      [Ver Detalhes]   │ │
│  │ 🌐 Orgânico • ☀️ Morno (65%)                           │ │
│  │ ⏱️ Aguardando há: 4m 12s                               │ │
│  │ 💬 "Preciso de ajuda com meu pedido"                  │ │
│  └────────────────────────────────────────────────────────┘ │
│                                                              │
│  🤖 ATENDIMENTOS AUTOMÁTICOS (192)                          │
│  [Ver Todos]                                                │
└─────────────────────────────────────────────────────────────┘
```

**Funcionalidades:**
- 🔴 Cor vermelha + badge piscante para urgentes
- ⏱️ Timer crescente (cria urgência visual)
- 📊 Contexto rico (origem, temperatura, valor estimado)
- 🔊 Som de alerta quando novo handoff entra
- 📱 Mobile-first design

#### 3.3 Sistema de Fila e Roteamento

**Lógica de Priorização:**

```typescript
// src/lib/handoff-queue.ts

export interface HandoffPriority {
  score: number; // 0-100
  factors: {
    urgency: number;      // Alta/Média/Baixa (do AI)
    leadTemperature: number; // Score do CRM
    waitTime: number;     // Quanto tempo esperando
    estimatedValue: number; // Valor potencial da venda
    attempts: number;     // Quantas vezes já tentou
  };
}

export const calculateHandoffPriority = (
  handoff: {
    urgency: 'high' | 'medium' | 'low';
    temperature: 'quente' | 'morno' | 'frio';
    temperatureScore: number;
    waitTimeSeconds: number;
    estimatedValue?: number;
    previousAttempts: number;
  }
): HandoffPriority => {

  const urgencyScore = {
    high: 100,
    medium: 60,
    low: 30
  }[handoff.urgency];

  const temperatureScore = handoff.temperatureScore;

  // Cada minuto esperando adiciona urgência
  const waitScore = Math.min(
    (handoff.waitTimeSeconds / 60) * 10, // +10 pontos por minuto
    50 // Máximo 50 pontos por tempo
  );

  // Valor estimado da venda
  const valueScore = handoff.estimatedValue
    ? Math.min((handoff.estimatedValue / 1000) * 5, 30)
    : 0;

  // Penaliza tentativas anteriores (pode ser lead difícil)
  const attemptPenalty = handoff.previousAttempts * -5;

  const totalScore = Math.max(
    0,
    Math.min(
      100,
      urgencyScore * 0.35 +
      temperatureScore * 0.25 +
      waitScore * 0.20 +
      valueScore * 0.15 +
      attemptPenalty * 0.05
    )
  );

  return {
    score: Math.round(totalScore),
    factors: {
      urgency: urgencyScore,
      leadTemperature: temperatureScore,
      waitTime: waitScore,
      estimatedValue: valueScore,
      attempts: attemptPenalty
    }
  };
};
```

**Exemplo Real:**

| Lead | Urgência | Temperatura | Espera | Valor | Tentativas | **Score** |
|------|----------|-------------|--------|-------|------------|-----------|
| João | High | 🔥 92 | 1m 23s | R$ 2.500 | 0 | **95** 🔴 |
| Maria | Medium | ☀️ 65 | 4m 12s | - | 1 | **68** 🟡 |
| Carlos | Low | ❄️ 32 | 10m | R$ 500 | 3 | **38** ⚪ |

**Ordem de Atendimento:** João → Maria → Carlos

#### 3.4 Backup Multi-Canal

**Redundância de Notificações:**

```
Bot detecta handoff
    ↓
┌─────────────────────────────┐
│ T+0s: Push Notification     │ ← Primeira tentativa
│ T+0s: Badge + Som           │
│ T+0s: Toast in-app          │
└─────────────────────────────┘
    ↓ (se não visto em 2 min)
┌─────────────────────────────┐
│ T+2m: Email de alerta       │ ← Backup automático
└─────────────────────────────┘
    ↓ (se não visto em 5 min)
┌─────────────────────────────┐
│ T+5m: SMS (opcional)        │ ← Último recurso
│ T+5m: Webhook para Slack    │
└─────────────────────────────┘
    ↓ (se não atendido em 10 min)
┌─────────────────────────────┐
│ T+10m: Escalar para gestor  │ ← Escalação automática
│ T+10m: Bot tenta resolver   │
└─────────────────────────────┘
```

---

## 4. COMPARAÇÃO DETALHADA - TABELA DE DECISÃO

| Critério | WhatsApp Pessoal (Não-Oficial) | WhatsApp Pessoal (Cloud API) | Notificações In-App |
|----------|--------------------------------|------------------------------|---------------------|
| **Risco de Banimento** | 🔴 ALTO (ToS violation) | 🟢 BAIXO (oficial) | 🟢 ZERO |
| **Custo Mensal** | R$ 1.150 (infra + DevOps) | R$ 50 (número extra) | R$ 0 (browser API) |
| **Complexidade Técnica** | 🔴 ALTA (Baileys + correlação) | 🟡 MÉDIA (2 WABAs + templates) | 🟢 BAIXA (PWA padrão) |
| **Estabilidade** | 🔴 BAIXA (desconexões) | 🟢 ALTA (Cloud API SLA 99.9%) | 🟢 ALTA (browser API) |
| **Latência** | 2-5s | 1-3s | < 1s |
| **Mobile-Friendly** | ✅ SIM (WhatsApp nativo) | ✅ SIM (WhatsApp nativo) | ⚠️ SIM (PWA ou app) |
| **Funciona Offline** | ❌ NÃO | ❌ NÃO | ⚠️ PARCIAL (cache) |
| **Conformidade LGPD** | 🔴 BAIXA (vazamento) | 🟢 ALTA (oficial) | 🟢 ALTA (controlado) |
| **Contexto Rico** | ⚠️ Texto limitado | ⚠️ Texto limitado | ✅ Dashboard completo |
| **Priorização Visual** | ❌ NÃO | ❌ NÃO | ✅ SIM (score + cores) |
| **Histórico/Auditoria** | ⚠️ Difícil | 🟢 Via webhook | 🟢 100% rastreável |
| **Tempo de Implementação** | 3-4 semanas | 2 semanas | 1 semana |
| **Escalabilidade** | 🟡 Limitada (1 Evolution por número) | 🟢 ALTA (Cloud API) | 🟢 ILIMITADA |

---

## 5. RECOMENDAÇÃO FINAL - ARQUITETURA HÍBRIDA

### Proposta: Começar com In-App + Adicionar Cloud API depois

**FASE 1 (SPRINT 1-2): Notificações In-App** ✅ IMPLEMENTAR AGORA

**Por que começar aqui:**
- ✅ Risco ZERO (sem ToS, sem ban)
- ✅ Custo ZERO
- ✅ Implementação rápida (1 semana)
- ✅ 80% do valor entregue (operador vê e atende rápido)

**Entregáveis:**
1. Push notifications (Web Push API)
2. Dashboard com badge vermelho + som
3. Sistema de priorização (fila inteligente)
4. Backup multi-canal (email + Slack opcional)

**Tempo:** 1 semana
**Custo:** R$ 0

---

**FASE 2 (SPRINT 3 - OPCIONAL): Cloud API para WhatsApp** ⚠️ AVALIAR DEPOIS

**Quando implementar:**
- ✅ Operadores pedirem explicitamente
- ✅ Métricas mostrarem que in-app não é suficiente
- ✅ Ter budget para R$ 50/mês (número extra)

**Entregáveis:**
1. Segundo número WABA (Bot-Notify)
2. Onboarding do operador (opt-in)
3. Sistema de correlação (case_id)
4. Roteamento bidirecional

**Tempo:** 2 semanas
**Custo:** R$ 50/mês operacional

---

**FASE X (NUNCA): Evolution API / Baileys** ❌ NÃO IMPLEMENTAR

**Por que não:**
- 🚫 Risco de perder o ativo principal (número oficial)
- 🚫 Violação de ToS (banimento permanente)
- 🚫 Instabilidade operacional
- 🚫 Risco de segurança (supply chain attack)
- 🚫 Não conformidade LGPD
- 🚫 Custo alto de manutenção

**Exceção:** NUNCA (não há cenário que justifique)

---

## 6. IMPLEMENTAÇÃO TÉCNICA - FASE 1 (IN-APP)

### 6.1 Migration - Tracking de Handoffs

```sql
-- supabase/migrations/20260220100000_handoff_notifications.sql

CREATE TABLE handoff_queue (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID NOT NULL REFERENCES clients(id),
  card_id UUID NOT NULL REFERENCES crm_cards(id),
  phone NUMERIC NOT NULL,

  -- Status
  status TEXT NOT NULL DEFAULT 'waiting', -- 'waiting' | 'assigned' | 'resolved' | 'expired'
  assigned_to UUID REFERENCES user_profiles(id),

  -- Metadata
  urgency TEXT NOT NULL, -- 'high' | 'medium' | 'low'
  reason TEXT NOT NULL,
  customer_name TEXT,
  last_message_preview TEXT,

  -- Priorização
  priority_score INTEGER NOT NULL DEFAULT 50,
  temperature TEXT, -- 'quente' | 'morno' | 'frio'
  temperature_score INTEGER,
  estimated_value NUMERIC(12,2),

  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  first_notified_at TIMESTAMPTZ,
  assigned_at TIMESTAMPTZ,
  resolved_at TIMESTAMPTZ,
  wait_time_seconds INTEGER GENERATED ALWAYS AS (
    EXTRACT(EPOCH FROM (COALESCE(resolved_at, NOW()) - created_at))::INTEGER
  ) STORED,

  -- Notificações
  notifications_sent INTEGER DEFAULT 0,
  last_notification_at TIMESTAMPTZ,
  notification_channels JSONB DEFAULT '[]', -- ['push', 'email', 'slack']

  UNIQUE(client_id, phone, status) WHERE status = 'waiting'
);

CREATE INDEX idx_handoff_queue_status ON handoff_queue(status) WHERE status = 'waiting';
CREATE INDEX idx_handoff_queue_priority ON handoff_queue(priority_score DESC) WHERE status = 'waiting';
CREATE INDEX idx_handoff_queue_assigned ON handoff_queue(assigned_to) WHERE status = 'assigned';

-- Função para criar handoff
CREATE OR REPLACE FUNCTION create_handoff(
  p_client_id UUID,
  p_card_id UUID,
  p_phone NUMERIC,
  p_urgency TEXT,
  p_reason TEXT,
  p_customer_name TEXT DEFAULT NULL,
  p_last_message TEXT DEFAULT NULL
) RETURNS UUID AS $$
DECLARE
  v_handoff_id UUID;
  v_temperature TEXT;
  v_temperature_score INTEGER;
  v_priority_score INTEGER;
BEGIN
  -- Buscar temperatura do lead
  SELECT temperature, confidence
  INTO v_temperature, v_temperature_score
  FROM lead_scores
  WHERE client_id = p_client_id AND card_id = p_card_id
  LIMIT 1;

  -- Calcular prioridade (simplificado - pode usar função complexa)
  v_priority_score := CASE
    WHEN p_urgency = 'high' THEN 90
    WHEN p_urgency = 'medium' THEN 60
    ELSE 30
  END;

  IF v_temperature = 'quente' THEN
    v_priority_score := v_priority_score + 10;
  END IF;

  -- Inserir handoff
  INSERT INTO handoff_queue (
    client_id,
    card_id,
    phone,
    urgency,
    reason,
    customer_name,
    last_message_preview,
    temperature,
    temperature_score,
    priority_score
  ) VALUES (
    p_client_id,
    p_card_id,
    p_phone,
    p_urgency,
    p_reason,
    p_customer_name,
    p_last_message,
    v_temperature,
    v_temperature_score,
    v_priority_score
  )
  ON CONFLICT (client_id, phone, status) WHERE status = 'waiting'
  DO UPDATE SET
    urgency = EXCLUDED.urgency,
    reason = EXCLUDED.reason,
    priority_score = EXCLUDED.priority_score
  RETURNING id INTO v_handoff_id;

  RETURN v_handoff_id;
END;
$$ LANGUAGE plpgsql;
```

### 6.2 Node - Criar Handoff

```typescript
// src/nodes/createHandoff.ts

import { createServerClient } from '@/lib/supabase-server';
import { sendPushNotification } from '@/lib/push-notifications';
import { sendSlackAlert } from '@/lib/slack-notifications';

export interface CreateHandoffInput {
  clientId: string;
  cardId: string;
  phone: string;
  urgency: 'high' | 'medium' | 'low';
  reason: string;
  customerName?: string;
  lastMessage?: string;
}

export const createHandoff = async (input: CreateHandoffInput) => {
  const supabase = createServerClient();

  // 1. Criar handoff no banco
  const { data: handoff, error } = await supabase.rpc('create_handoff', {
    p_client_id: input.clientId,
    p_card_id: input.cardId,
    p_phone: input.phone,
    p_urgency: input.urgency,
    p_reason: input.reason,
    p_customer_name: input.customerName,
    p_last_message: input.lastMessage
  });

  if (error) throw error;

  // 2. Atualizar status do card CRM
  await supabase
    .from('crm_cards')
    .update({
      needs_attention: true,
      auto_status: 'awaiting_attendant'
    })
    .eq('id', input.cardId);

  // 3. Buscar operadores disponíveis
  const { data: operators } = await supabase
    .from('user_profiles')
    .select('id, push_subscription')
    .eq('client_id', input.clientId)
    .eq('role', 'operator')
    .eq('is_active', true);

  if (!operators || operators.length === 0) {
    console.warn('[Handoff] No operators available for client', input.clientId);
    return { handoffId: handoff, notificationsSent: 0 };
  }

  // 4. Enviar notificações push para todos operadores
  const notificationPromises = operators.map(async (op) => {
    if (!op.push_subscription) return false;

    try {
      await sendPushNotification(op.id, {
        title: '🔴 Atendimento Urgente',
        body: `${input.customerName || 'Cliente'} precisa de atendimento humano agora!`,
        icon: '/icon-192.png',
        badge: '/badge-72.png',
        data: {
          cardId: input.cardId,
          clientId: input.clientId,
          phone: input.phone,
          urgency: input.urgency,
          handoffId: handoff
        }
      });
      return true;
    } catch (err) {
      console.error('[Handoff] Push notification failed', err);
      return false;
    }
  });

  const results = await Promise.all(notificationPromises);
  const successCount = results.filter(Boolean).length;

  // 5. Backup: Enviar email se nenhuma push funcionou
  if (successCount === 0) {
    await sendEmailBackup(input);
  }

  // 6. Opcional: Slack notification
  if (input.urgency === 'high') {
    await sendSlackAlert({
      channel: '#atendimento-urgente',
      text: `🚨 *Atendimento Urgente:* ${input.customerName || 'Cliente'} (${input.phone})`,
      blocks: [
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: `*Motivo:* ${input.reason}\n*Última mensagem:* ${input.lastMessage || 'N/A'}`
          }
        },
        {
          type: 'actions',
          elements: [
            {
              type: 'button',
              text: { type: 'plain_text', text: 'Atender Agora' },
              url: `https://chat.luisfboff.com/dashboard/crm/${input.cardId}`
            }
          ]
        }
      ]
    });
  }

  // 7. Atualizar log de notificações
  await supabase
    .from('handoff_queue')
    .update({
      notifications_sent: successCount,
      first_notified_at: new Date().toISOString(),
      last_notification_at: new Date().toISOString(),
      notification_channels: ['push', successCount === 0 ? 'email' : null].filter(Boolean)
    })
    .eq('id', handoff);

  return {
    handoffId: handoff,
    notificationsSent: successCount,
    operatorsNotified: operators.length
  };
};
```

### 6.3 Integration no chatbotFlow.ts

```typescript
// src/flows/chatbotFlow.ts

import { createHandoff } from '@/nodes/createHandoff';

// ... após NODE 11: Generate AI Response

// NODE 14: Check for Human Handoff
if (aiResponse.toolCalls?.some(tool => tool.function.name === 'transferir_atendimento')) {
  const handoffTool = aiResponse.toolCalls.find(
    tool => tool.function.name === 'transferir_atendimento'
  );

  const handoffParams = JSON.parse(handoffTool.function.arguments);

  // Criar handoff e notificar operadores
  const handoffResult = await createHandoff({
    clientId: config.id,
    cardId: crmCardId,
    phone: parsedMessage.phone,
    urgency: handoffParams.urgencia || 'medium',
    reason: handoffParams.motivo || 'Cliente solicitou atendimento humano',
    customerName: parsedMessage.name,
    lastMessage: parsedMessage.content
  });

  console.log('[Flow] Handoff created:', handoffResult);

  // Atualizar status
  await supabase
    .from('clientes_whatsapp')
    .update({ status: 'transferido' })
    .eq('telefone', parsedMessage.phone);

  // Enviar mensagem de confirmação para o cliente
  await sendWhatsAppMessage(
    parsedMessage.phone,
    'Entendi! Estou transferindo você para um de nossos especialistas. ' +
    'Você será atendido em breve. Obrigado pela paciência! 😊'
  );

  // IMPORTANTE: Parar o bot para este cliente
  return {
    success: true,
    handoff: true,
    handoffId: handoffResult.handoffId,
    message: 'Transferido para atendimento humano'
  };
}
```

### 6.4 Frontend - Dashboard Component

```typescript
// src/app/dashboard/crm/components/HandoffQueue.tsx

'use client';

import { useEffect, useState } from 'react';
import { createBrowserClient } from '@/lib/supabase-client';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useRouter } from 'next/navigation';

interface HandoffItem {
  id: string;
  customer_name: string;
  phone: string;
  urgency: 'high' | 'medium' | 'low';
  reason: string;
  last_message_preview: string;
  temperature: 'quente' | 'morno' | 'frio';
  temperature_score: number;
  priority_score: number;
  wait_time_seconds: number;
  created_at: string;
}

export const HandoffQueue = () => {
  const [handoffs, setHandoffs] = useState<HandoffItem[]>([]);
  const [playSound, setPlaySound] = useState(false);
  const router = useRouter();
  const supabase = createBrowserClient();

  useEffect(() => {
    // Carregar handoffs iniciais
    loadHandoffs();

    // Realtime subscription
    const channel = supabase
      .channel('handoff_queue_changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'handoff_queue',
          filter: 'status=eq.waiting'
        },
        (payload) => {
          setHandoffs((prev) => [payload.new as HandoffItem, ...prev]);
          setPlaySound(true); // Toca som de alerta
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'handoff_queue'
        },
        (payload) => {
          setHandoffs((prev) =>
            prev.map((h) => (h.id === payload.new.id ? (payload.new as HandoffItem) : h))
          );
        }
      )
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (playSound) {
      const audio = new Audio('/sounds/alert.mp3');
      audio.play();
      setPlaySound(false);
    }
  }, [playSound]);

  const loadHandoffs = async () => {
    const { data } = await supabase
      .from('handoff_queue')
      .select('*')
      .eq('status', 'waiting')
      .order('priority_score', { ascending: false });

    setHandoffs(data || []);
  };

  const handleAttend = async (handoffId: string, cardId: string) => {
    // Atribuir para mim
    await supabase
      .from('handoff_queue')
      .update({
        status: 'assigned',
        assigned_at: new Date().toISOString()
      })
      .eq('id', handoffId);

    // Redirecionar para chat
    router.push(`/dashboard/chat/${cardId}`);
  };

  if (handoffs.length === 0) {
    return null;
  }

  return (
    <div className="mb-6 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">
          ⚠️ Aguardando Atendimento Humano
        </h2>
        <Badge variant="destructive" className="animate-pulse">
          {handoffs.length} urgente{handoffs.length > 1 ? 's' : ''}
        </Badge>
      </div>

      <div className="space-y-3">
        {handoffs.map((handoff) => {
          const urgencyColor = {
            high: 'bg-red-50 border-red-300',
            medium: 'bg-yellow-50 border-yellow-300',
            low: 'bg-gray-50 border-gray-300'
          }[handoff.urgency];

          const tempEmoji = {
            quente: '🔥',
            morno: '☀️',
            frio: '❄️'
          }[handoff.temperature] || '❓';

          return (
            <div
              key={handoff.id}
              className={`border rounded-lg p-4 ${urgencyColor}`}
            >
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="font-semibold">
                    {handoff.urgency === 'high' && '🔴 '}
                    {handoff.customer_name || 'Cliente'}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {tempEmoji} {handoff.temperature} ({handoff.temperature_score}%) •
                    Aguardando há {Math.floor(handoff.wait_time_seconds / 60)}m {handoff.wait_time_seconds % 60}s
                  </p>
                </div>
                <Button
                  size="sm"
                  variant={handoff.urgency === 'high' ? 'destructive' : 'default'}
                  onClick={() => handleAttend(handoff.id, handoff.card_id)}
                >
                  Atender Agora
                </Button>
              </div>

              <p className="text-sm mb-2">
                <strong>Motivo:</strong> {handoff.reason}
              </p>

              {handoff.last_message_preview && (
                <p className="text-sm text-gray-600 italic">
                  💬 "{handoff.last_message_preview}"
                </p>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
```

---

## 7. CHECKLIST DE IMPLEMENTAÇÃO

### Sprint 1 (Semana 1): Foundation

- [ ] Migration: `handoff_queue` table
- [ ] Function SQL: `create_handoff()`
- [ ] Node: `createHandoff.ts`
- [ ] Lib: `push-notifications.ts` (Web Push API)
- [ ] Integration: Adicionar NODE 14 em `chatbotFlow.ts`
- [ ] Test: Criar handoff manual e verificar criação

### Sprint 2 (Semana 2): Dashboard

- [ ] Component: `HandoffQueue.tsx`
- [ ] Realtime: Supabase subscription para INSERT/UPDATE
- [ ] Sound: Adicionar `/public/sounds/alert.mp3`
- [ ] Badge: Contador animado no header
- [ ] Actions: Botão "Atender Agora" funcional
- [ ] Test: E2E flow (bot → handoff → notificação → atendimento)

### Sprint 3 (Opcional): Backup Multi-Canal

- [ ] Email backup (se push falhar em 2 min)
- [ ] Slack integration (urgência alta)
- [ ] SMS (Twilio) - último recurso
- [ ] Escalação automática (10 min sem atendimento)

---

## 8. MÉTRICAS DE SUCESSO

**Antes (Sistema Atual):**
- Tempo médio de resposta: 15-30 min (email)
- Taxa de abandono: 23%
- Satisfação: 6.5/10

**Meta (Após Implementação):**
- Tempo médio de resposta: < 5 min
- Taxa de abandono: < 10%
- Satisfação: > 8.5/10

**KPIs para Monitorar:**
- Tempo médio de espera (`wait_time_seconds`)
- Taxa de handoffs resolvidos em < 5 min
- % de notificações entregues com sucesso
- Taxa de escalação (handoffs não atendidos em 10 min)

---

## 9. DECISÃO FINAL - O QUE FAZER?

### ✅ IMPLEMENTAR AGORA:

**Notificações In-App (FASE 1)**
- Custo: R$ 0
- Risco: ZERO
- Tempo: 2 semanas
- ROI: ALTO

### ⚠️ AVALIAR DEPOIS (2-4 semanas):

**Cloud API WhatsApp (FASE 2)**
- Custo: R$ 50/mês
- Risco: BAIXO
- Só se operadores pedirem

### ❌ NUNCA FAZER:

**Evolution API / Baileys**
- Risco de banimento permanente
- Violação de ToS
- Custo alto (R$ 1.150/mês)
- Instabilidade

---

**FIM DO DOCUMENTO**

**Próximo Passo:** Apresentar para Luis e aprovar FASE 1 (in-app notifications)
